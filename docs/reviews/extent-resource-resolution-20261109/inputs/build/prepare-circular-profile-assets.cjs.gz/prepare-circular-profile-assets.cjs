// Explicit component native build; existing assets/defaults are unchanged.
const path=require('node:path'),fs=require('node:fs'),crypto=require('node:crypto');
<<<<<<< HEAD
const bootstrapSha='7864b6ca0e29ccc3a985d4950e02b0faf720d83f95b71e2f7e388310b4525945';
=======
const bootstrapSha='a3baeaba27a596511d205de81babada5366159b5812c026decee9d2b7890b5b8';
>>>>>>> 8678c35b770855fa3978abfeab789c76f303bfd1
if(crypto.createHash('sha256').update(fs.readFileSync(path.resolve(__dirname,'../modules/engine/mount/oci-verified-worker.js'))).digest('hex')!==bootstrapSha)throw Error('Unexpected circular bootstrap');
const {stageOwnedProfileComponent}=require('./stage-owned-profile-component.cjs');
const defaultOutput=path.resolve(__dirname,'../.build/circular-assets');
if(fs.existsSync(process.argv[3]||defaultOutput))throw Error('Use a fresh circular component output');
stageOwnedProfileComponent({circularArrangementVersion:1,selectedRegionArrangementVersion:1,input:process.argv[2],output:process.argv[3]||defaultOutput,defaultOutput,
 jsSha:'9789a61709dc680cce64dfa29030a3862ee636319594bdc839c0ed92e9d3571b',
 wasmSha:'707facb3d09aa4f84d7e0d2690141ceaf90315d2f69d110f9f763f52dc192649',
 constructorModule:'modules/engine/mount/occ-circular-mount.mjs',
 rootModules:["modules/engine/mount/ownedCircularNativeContract.mjs","modules/engine/mount/ownedCircularWorker.mjs","modules/engine/mount/ownedCircularArrangementProtocol.mjs","modules/engine/mount/circularArrangementPlan.mjs","modules/engine/mount/circularPrismSelectionIndex.mjs","modules/engine/extrusion/circularArrangementDescriptor.mjs","modules/engine/extrusion/circularTopology.mjs",'modules/engine/mount/nativePlanarAttachmentFacts.mjs','modules/engine/mount/ownedPlanarAttachmentProtocol.mjs','modules/engine/extrusion/isolatedOpenProfileComponents.mjs','modules/engine/mount/ownedShellWorker.mjs','modules/engine/mount/ownedDrawingDerivedProtocol.mjs','modules/engine/mount/ownedDrawingSectionProtocol.mjs','modules/engine/mount/ownedDrawingSectionWorker.mjs','modules/engine/mount/drawingDetailClip.mjs','modules/engine/mount/ownedDrawingReadProtocol.mjs','modules/engine/mount/drawingReferenceFacts.mjs','modules/engine/mount/prismaticBoreFacts.mjs','modules/engine/mount/ownedBoreReadProtocol.mjs','modules/engine/mount/ownedBoreAnnotationProtocol.mjs','modules/engine/mount/cylinderCutWitness.mjs','modules/engine/extrusion/selectedRegionDescriptor.mjs','modules/drawing/linkedPartDrawingDefinition.mjs','modules/engine/mount/manufacturingMeshRecord.mjs','modules/engine/mount/orthographicAnalyticRecord.mjs','modules/engine/mount/ownedLoftPlan.mjs','modules/engine/mount/ownedSweepPlan.mjs','modules/engine/mount/ownedRevolvePlan.mjs','modules/engine/mount/ownedLinearHolePatternPlan.mjs','modules/engine/mount/ownedThroughHolePlan.mjs','modules/engine/mount/selectionLineageIndex.mjs','modules/engine/mount/ownedBooleanContract.mjs','modules/engine/mount/selectionAncestryIndex.mjs'],
 workerName:'circular-worker.js',prefix:'circular',format:'circular-component/1'});
